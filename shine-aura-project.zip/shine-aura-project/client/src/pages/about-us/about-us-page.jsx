import React from "react";
import ImageSlider from "../../components/about-us/image-slider/image-slider";
import Button from "../../components/common/button/button";
import DropdownButton from "../../components/common/button/dropdown-button";
import "./about-us-page.css";

import UsImage from "../../assets/img/about-us/us.png"
import SkincareImage from "../../assets/img/about-us/skin-care.png";
import MakeupImage from "../../assets/img/about-us/makeup.png";
import Value1 from "../../assets/img/about-us/value-1.png";
import Value2 from "../../assets/img/about-us/value-2.png";
import Value3 from "../../assets/img/about-us/value-3.png";
import Value4 from "../../assets/img/about-us/value-4.png";
import Value5 from "../../assets/img/about-us/value-5.png";
import Value6 from "../../assets/img/about-us/value-6.png";

const sliderImages = [
    UsImage,
    SkincareImage,
    MakeupImage
]

const valueImages = [
    Value1,
    Value2,
    Value3,
    Value4,
    Value5,
    Value6
]

const AboutUsPage = () => {
    const imageWidth = `calc(100% / ${valueImages.length} - 32px)`;
    
    return (
        <div className = 'AboutUsPage-shine'>
            <div className="flex-col content-container">
                <div className="hero-image">
                    <img src={UsImage} alt="us" />
                </div>
                <div className="sectionContainer flex-col">
                    <div className="section gap-md flex-col">
                        <h2 className="h2">What we do.</h2>
                        <p className="body">Sit anim in id enim aliqua sint labore non officia mollit esse Lorem amet aliqua laborum excepteur est aliquip elit.</p>
                            <div className="flex-row">
                                <div className="flex-col">
                                    <img className="img-size" src={SkincareImage} alt="" />
                                    <div className="md-spc gap-ms flex-col ivory-bg">
                                        <h3 className="h3">Skincare</h3>
                                        <p className="body">Excepteur consequat labore voluptate adipisicing elit nostrud quis commodo. Ad cillum nostrud mollit </p>
                                    </div>
                                </div>
                                <div className="flex-col">
                                    <img className="img-size" src={MakeupImage} alt="" />
                                    <div className="md-spc gap-ms flex-col ivory-bg">
                                        <h3 className="h3">Makeup</h3>
                                        <p className="body">Excepteur consequat labore voluptate adipisicing elit nostrud quis commodo. Ad cillum nostrud mollit </p>
                                    </div>
                                </div>
                            </div>
                    </div>
                </div>
                <div className="sectionContainer flex-col ourStoryContainer">
                    <div className="section our-story">
                        <div className="right-container flex-row">
                            <ImageSlider images={sliderImages}/>
                        </div>
                        <div className="left-container flex-col flex-align-top md-spc">
                            <p class="pre-title">About  us</p>
                            <h2 className="h2">Our Story</h2>
                            <p className="body">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis vel tellus lectus. Sed sagittis, risus vitae dignissim semper, turpis arcu congue augue, eget ornare orci libero nec enim. Aenean a aliquam nunc. Morbi tincidunt mattis nulla et interdum. Donec mollis tincidunt pellentesque. Vivamus laoreet sodales accumsan. Integer ornare vulputate mi posuere elementum.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis vel tellus lectus. Sed sagittis, risus vitae dignissim semper, turpis arcu congue augue, eget ornare orci libero nec enim. Aenean a aliquam nunc. Morbi tincidunt mattis nulla et interdum. Donec mollis tincidunt pellentesque. Vivamus laoreet sodales accumsan. Integer ornare vulputate mi posuere elementum.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis vel tellus lectus. Sed sagittis, risus vitae dignissim semper, turpis arcu congue augue, eget ornare orci libero nec enim. Aenean a aliquam nunc.</p>
                        </div>
                    </div>
                </div>
                <div className="sectionContainer flex-col">
                    <div className="section flex-col our-value gap-lg">
                        <h2 className="h2">OUR VALUE</h2>
                        <div className="flex-row flex-l gap-md value-images">
                            {valueImages.map((image, index) => (
                                <img
                                key={index}
                                src={image}
                                alt={`${index + 1}`}
                                style={{ width: imageWidth }}
                                />
                            ))}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
};

export default AboutUsPage;